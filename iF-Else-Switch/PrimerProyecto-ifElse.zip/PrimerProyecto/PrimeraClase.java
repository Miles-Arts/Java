
/**
 * Write a description of class PrimeraClase here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

// Hola soy un comentario :)
public class PrimeraClase
{
   
  public static void main (String[] args){
     
      int edad = 19;
      String descripcionEdad = "";
      String nombre = "Juan";
      // if = si "la pregunta tiene respuesta verdadera" 
      //entra a mi estructura
      // < , > , == , >= , <= Operadores comparación
      //Operadores Logicos
      // && El operador L. "Y" y entra al ser todo verdadero
      // || El operador L. "O" y entra al ser una o varias de las P.V.
      if  ((edad >= 18 && edad <=40)  {
        if (edad < 18 && nombre == Macarena){
            
            if (edad < 18 && nombre == Macarena){
            
            
            }
            }
          
      descripcionEdad = "Tu eres mayor de edad, si puedes entrar al bar";   
     System.out.println(descripcionEdad);
        
        }else if (nombre == "Miranda"){
        descripcionEdad = "Tu eres menor de edad, no puedes pasar al bar";
         System.out.println(descripcionEdad);
        
        }
    
      
    } 
     
    
    
    
}
